$(document).ready(function() {
    
    /* _________________ start home page _________________ */
    
    // header style change on page scroll
    function changeHeaderStyle() {
        if ($(window).scrollTop() > 50) {
            $("header").addClass("scrolled");
        } else {
            $("header").removeClass("scrolled");
        }
    }
    changeHeaderStyle();
    $(window).on("scroll", function () {
        changeHeaderStyle();
    });

    // toggle side menu for small devices
    $(".menu_toggleBtn,.header_backDrop").click(function() {
        $(".header").toggleClass("active_header");
    });
    
    // partners/brands slider
    $(".partners_slider").owlCarousel({
        items: 3, 
        loop: true,
        margin: 10,
        autoplay: true,
        autoplayTimeout: 4000, 
        autoplayHoverPause: false,
        autoplaySpeed: 4000,
        smartSpeed: 4000, 
        slideTransition: 'linear', 
        dots: false,
        nav: false,
        responsive:{
            576:{
                items:4,
                margin:12
            },
            768:{
                items:5,
                margin:16
            },
            992:{
                items:7,
                margin:32
            }
        }
    });

    // customer review slider
    $(".customer_review_slider").owlCarousel({
        items: 1, 
        loop: true,
        margin: 12,
        dots: false,
        nav: true,
        navText:['<i class="fa-solid fa-arrow-left"></i>','<i class="fa-solid fa-arrow-right"></i>'],
        stagePadding:8,
        responsive:{
            576:{
                items:2,
                margin:12
            },
            768:{
                items:3,
                margin:16
            },
            992:{
                items:4,
                margin:24
            }
        }
    });
    /* _________________ end home page _________________ */
    
    /* _________________ start services page _________________ */
    
    // see all option
    $(".seeAll_optBtn").click(function(){
        $(this).parents(".opt_list").toggleClass("see_all");
    });

    // initialize select2js
    $('.select2default').select2({
        dropdownAutoWidth: true,
        width:'auto',
        minimumResultsForSearch: Infinity
    });
    
    // tooltip initialize 
    $('[data-bs-toggle="tooltip"]').tooltip();

    /* _________________ end services page _________________ */
});